package com.dicoding.associate.cataloguemovie;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, LoaderManager.LoaderCallbacks<ArrayList<FilmItems>>, AdapterView.OnItemClickListener {

    private ListView listView;
    private FilmAdapter adapter;
    private EditText edt_search;
    private Button btn_search;
    private ProgressBar progressBar;

    public static final String TAG = "My Catalogue Film";
    static final String JUDUL_FILM = "judul_film";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = new FilmAdapter(this);
        adapter.notifyDataSetChanged();
        listView = findViewById(R.id.lv_film);

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        edt_search = findViewById(R.id.edt_search);
        btn_search = findViewById(R.id.btn_search);
        btn_search.setOnClickListener(this);

        progressBar = findViewById(R.id.progress_bar);
        progressBar.setVisibility(View.GONE);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_search) {
            String judul = edt_search.getText().toString();
            if (TextUtils.isEmpty(judul)) {
                edt_search.setError("Field harus diisi");
            } else {
//                Log.d(TAG, "button On Click");
                Bundle bundle = new Bundle();
                bundle.putString(JUDUL_FILM, judul);

                getLoaderManager().restartLoader(0, bundle,MainActivity.this);
            }
        }
    }

    @Override
    public Loader<ArrayList<FilmItems>> onCreateLoader(int i, Bundle bundle) {
        String judul = "";
        if (bundle != null) {
            judul = bundle.getString(JUDUL_FILM);
        }

        adapter.setData(null);
        progressBar.setVisibility(View.VISIBLE);
        return new MyAsyncTaskLoader(this, judul);
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<FilmItems>> loader, ArrayList<FilmItems> filmItems) {
        progressBar.setVisibility(View.GONE);
        adapter.setData(filmItems);
    }

    @Override
    public void onLoaderReset(Loader<ArrayList<FilmItems>> loader) {
        adapter.setData(null);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        FilmItems items = (FilmItems) adapterView.getItemAtPosition(i);
        Intent intent = new Intent(MainActivity.this, FilmDetailActivity.class);

        intent.putExtra(FilmDetailActivity.EXTRA_TITLE, items.getTitle());
        intent.putExtra(FilmDetailActivity.EXTRA_RELEASE, items.getDateRelease());
        intent.putExtra(FilmDetailActivity.EXTRA_DESC, items.getDesc());
        intent.putExtra(FilmDetailActivity.EXTRA_PATH, items.getPosterPath());

        startActivity(intent);
    }
}
