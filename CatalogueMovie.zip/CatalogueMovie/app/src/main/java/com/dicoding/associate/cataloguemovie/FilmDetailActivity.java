package com.dicoding.associate.cataloguemovie;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FilmDetailActivity extends AppCompatActivity {

    public static final String EXTRA_TITLE = "extra_title";
    public static final String EXTRA_RELEASE = "extra_release";
    public static final String EXTRA_DESC = "extra_desc";
    public static final String EXTRA_PATH = "extra_path";

    private TextView tvDetailTitle, tvDetailRelease, tvDetailDesc;
    private ImageView ivDetailPoster;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_detail);

        tvDetailTitle = findViewById(R.id.tv_detail_title);
        tvDetailRelease = findViewById(R.id.tv_detail_release);
        tvDetailDesc = findViewById(R.id.tv_detail_desc);
        ivDetailPoster = findViewById(R.id.iv_detail_poster);

        tvDetailTitle.setText(getIntent().getStringExtra(EXTRA_TITLE));
        tvDetailRelease.setText(setDateFormat(getIntent().getStringExtra(EXTRA_RELEASE)));
        tvDetailDesc.setText(getIntent().getStringExtra(EXTRA_DESC));
        Glide.with(this).load("http://image.tmdb.org/t/p/w154/" + getIntent().getStringExtra(EXTRA_PATH)).into(ivDetailPoster);

    }

    private String setDateFormat(String date) {
        //Set Release Date
        Date rawDate = null;
        SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
        try {
            rawDate = formatDate.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        SimpleDateFormat newFormat = new SimpleDateFormat("EEEE, MMM dd, yyyy");
        String dateRelease = "";
        if (rawDate != null) dateRelease = newFormat.format(rawDate);
        return dateRelease;
    }
}
