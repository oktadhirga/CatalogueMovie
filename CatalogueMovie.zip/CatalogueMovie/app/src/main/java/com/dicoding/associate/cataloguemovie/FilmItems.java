package com.dicoding.associate.cataloguemovie;

import org.json.JSONObject;

public class FilmItems {

    private int id;
    private String posterPath;
    private String title;
    private String desc;
    private String dateRelease;

    public FilmItems(JSONObject film) {

        try {
            this.id = film.getInt("id");
            this.posterPath = film.getString("poster_path");
            this.title = film.getString("title");
            this.desc = film.getString("overview");
            this.dateRelease = film.getString("release_date");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDateRelease() {
        return dateRelease;
    }

    public void setDateRelease(String dateRelease) {
        this.dateRelease = dateRelease;
    }
}
