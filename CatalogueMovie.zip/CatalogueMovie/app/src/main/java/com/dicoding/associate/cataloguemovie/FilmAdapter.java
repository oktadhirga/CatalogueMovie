package com.dicoding.associate.cataloguemovie;

import android.content.Context;
import android.nfc.Tag;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class FilmAdapter extends BaseAdapter {

    private ArrayList<FilmItems> mData = new ArrayList<>();
    private LayoutInflater inflater;
    private Context context;

    public FilmAdapter(Context context) {
        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void setData(ArrayList<FilmItems> data) {
        this.mData = data;
        notifyDataSetChanged();
    }

    public void addItem(final FilmItems item) {
        mData.add(item);
        notifyDataSetChanged();
    }

    public void clearData() {
        mData.clear();
    }

    @Override
    public int getCount() {
        if (mData == null) return 0;
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if (view == null) {
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.film_items, null);
            holder.textViewTitle = view.findViewById(R.id.tv_title_film);
            holder.textViewDesc = view.findViewById(R.id.tv_desc_film);
            holder.textViewReleaseDate = view.findViewById(R.id.tv_date_release);
            holder.imageViewFilm = view.findViewById(R.id.image_film);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }

        //Set Release Date
        Date rawDate = null;
        String date = mData.get(i).getDateRelease();
        SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
        try {
            rawDate = formatDate.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        SimpleDateFormat newFormat = new SimpleDateFormat("EEEE, MMM dd, yyyy");
        String dateRelease = "";
        if (rawDate != null) dateRelease = newFormat.format(rawDate);

        holder.textViewTitle.setText(mData.get(i).getTitle());
        holder.textViewDesc.setText(mData.get(i).getDesc());
        holder.textViewReleaseDate.setText(dateRelease);
        Glide.with(context).load("http://image.tmdb.org/t/p/w92/" + mData.get(i).getPosterPath()).into(holder.imageViewFilm);
        Log.d("My Catalogue Film", mData.get(i).getPosterPath());

        return view;
    }

    private class ViewHolder {
        TextView textViewTitle;
        TextView textViewDesc;
        TextView textViewReleaseDate;
        ImageView imageViewFilm;
    }
}
